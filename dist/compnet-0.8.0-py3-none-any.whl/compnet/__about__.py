"""  Created on 26/05/2023::
------------- __about__.py -------------

**Authors**: L. Mingarelli
"""

__about__ = "A package for market compression of network data."
__version__= '0.8.0'
__author__ = 'Luca Mingarelli'
__email__ = "lucamingarelli@me.com"
__url__ = "https://github.com/LucaMingarelli/compnet"

